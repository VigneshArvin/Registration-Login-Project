export interface User {
    fName: string;
    phone: string;
    email: string;
    pass: string;
}
