import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { AuthenticationServiceService } from '../services/authentication-service.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  username:string;
  password:string;
  loginForm: FormGroup;
  loading = false;
  submitted = false;
  toastrAppAlerts: any = [];
  toastrImpactAlerts: any = [];

  showAlerts(tabName: string) {
    let g: any[] = [];  
if (tabName == 'app')
      g = this.toastrAppAlerts;  
else if (tabName == 'impact')
      g = this.toastrImpactAlerts;
 g.forEach(element => {
     if (element['type'] == 'success') this.alert.success(element['msg']);
     else if (element['type'] == 'error') this.alert.error(element['msg']);
     else if (element['type'] == 'info') this.alert.info(element['msg']); 
     else if (element['type'] == 'warning') this.alert.warning(element['msg']);
 });
  }
  constructor(
    private formbuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private authenticationservice: AuthenticationServiceService,
    private alert : ToastrService
  ) { }

  ngOnInit() {
    this.loginForm = this.formbuilder.group({
      username: ['',Validators.required],
      password: ['',Validators.required]
    });
  }
  get f() {
    return this.loginForm.controls;
  }
  onSubmit(name:string, pass:string){
    window.alert(name+' '+pass);
    this.authenticationservice.login(name,pass).subscribe(data => {
      console.log('Logged In'+JSON.stringify(data));
      if(data!=null){
        this.alert.success('Authenticated');
        this.router.navigate(['./pages']);
      }
      else
        this.alert.error('Not Authenticated! Invalid Username or Password')
     
    });
  

    this.submitted = true;
    if(this.loginForm.invalid){
      return;
    }
    this.loading = true;
    this.authenticationservice.login(this.f.username.value,this.f.password.value)
  }

}
