import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { User } from '../models/user';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationServiceService {

  constructor( private http: HttpClient) { }

  login(username:string,password:string){
    console.log(username+'in auth service');
      return this.http.post<any>('http://localhost:8085/user/authenticate',{username,password});
      
  }


  userRegistration(newUser : User):Observable<any>{
    var newData = { firstname : newUser.fName,
                    phone : newUser.phone,
                    email : newUser.email,
                    password : newUser.pass,
                    }
    console.log('Registeration data log in Service call'+JSON.stringify(newUser));
    return this.http.post<any>('http://localhost:8085/user/register', newData);

  }
}
   