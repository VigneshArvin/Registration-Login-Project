import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { User } from '../models/user';
import { AuthenticationServiceService } from '../services/authentication-service.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  user: User = {fName : '', lName: '', phone: '', email :'', pass: ''};
  userdetail: User;
  registerForm: FormGroup;
  constructor(
    private registerService: AuthenticationServiceService,
    private router: Router,
    private alert : ToastrService,
    private fb : FormBuilder 
  ) {
    this.registerForm = this.fb.group({
      firstName: ['',Validators.minLength(3)],
      phone:['',[Validators.required, Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]],
      email: ['',Validators.email],
      password: ['',Validators.required],
      confirmpassword: ['',this.passValidator],
      checkbox : ['',Validators.required]
    });
   }

  ngOnInit(): void {
  }
 
public onFormSubmit() {  
this.user.fName=this.registerForm.value.firstName;
this.user.phone =this.registerForm.value.phone;
this.user.email=this.registerForm.value.email;
this.user.pass=this.registerForm.value.confirmpassword;

 console.log('Registeration data log in TS'+this.user);
    this.registerService.userRegistration(this.user)
    .subscribe((res)=>{   
      console.log('Registered return service data...'+res);   
      this.router.navigate(['/login']);
    },
    (err)=>{
      console.log(err);
      this.alert.error('Error Saving Data, Please try later!', 'Registration Unsuccessful');
    });
  }

   passValidator(control: AbstractControl) {
      if (control && (control.value !== null || control.value !== undefined)) {
          const cnfpassValue = control.value;
  
          const passControl = control.root.get('password');
          if (passControl) {
              const passValue = passControl.value;
              if (passValue !== cnfpassValue || passValue === '') {
                  return {
                      isError: true
                  };
              }
          }
      }
  
      return null;
  }
}
