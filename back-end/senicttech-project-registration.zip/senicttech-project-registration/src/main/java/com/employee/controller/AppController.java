package com.employee.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.employee.entity.Registration;
import com.employee.entity.User;
import com.employee.repository.RegistrationRepository;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
public class AppController {
	
	@Autowired
	private RegistrationRepository registerRepo;
	
	@RequestMapping(value = "/user/register", method = RequestMethod.POST)
	public ResponseEntity<String> registerUser(@RequestBody Registration register) {
	boolean userAlreadyPresent = false;
	String userName= register.getName();
	List<Registration> nameDBO = registerRepo.findByFirstName(userName);
	for(Registration name : nameDBO) {
		if(name.getName().equals(userName)) {
			userAlreadyPresent = true;
			break;
		}
	}
	
		if(userAlreadyPresent){
			return new ResponseEntity<String>("{\"[WARN]\": \"User already exists!\"}", HttpStatus.CONFLICT);
		}
		else {
			registerRepo.save(register);
			
			return new ResponseEntity<String>("{\"[INFO]\": \"User succesfully Registered!\"}", HttpStatus.CREATED);
		}
   }
	
	@RequestMapping(value="/user/login", method = RequestMethod.POST)
	public ResponseEntity<String> Login(@RequestBody User user) throws Exception {
		boolean authenticate = false;
		List<Registration> list= registerRepo.findByEmail(user.getEmail());
		for(Registration register: list) {
			if(register.getEmail().equals(user.getEmail())) {
				if(register.getPassword().equals(user.getPassword()))
					authenticate = true;
				else 
					authenticate = false;
			}
			else {
				return new ResponseEntity<String>("{\"[WARN]\": \"User Not Found!\"}", HttpStatus.UNAUTHORIZED);
			}
		}
		
		if(authenticate)
			return new ResponseEntity<String>("{\"[INFO]\": \"User Authenticated Successfully!\"}", HttpStatus.ACCEPTED);
		else	
		return new ResponseEntity<String>("{\"[WARN]\": \"User Not Authenticated!\"}", HttpStatus.UNAUTHORIZED);
		
	}

 }
