export interface User {
    name: string;
    phone: string;
    email: string;
    pass: string;
}
