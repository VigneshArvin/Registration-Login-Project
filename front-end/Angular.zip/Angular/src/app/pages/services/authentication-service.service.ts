import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { User } from '../models/user';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationServiceService {

  constructor( private http: HttpClient) { }

  login(email:string,password:string){
    console.log(email+'in auth service');
      return this.http.post<any>('http://localhost:8085/user/login',{email,password});
      
  }


  userRegistration(newUser : User):Observable<any>{
    var newData = { name : newUser.name,
                    phone : newUser.phone,
                    email : newUser.email,
                    password : newUser.pass,
                    }
    console.log('Registeration data log in Service call'+JSON.stringify(newUser));
    return this.http.post<any>('http://localhost:8085/user/register', newData);

  }
}
   